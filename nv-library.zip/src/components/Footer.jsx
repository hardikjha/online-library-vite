export default function Footer() {
  return (
    <footer className="footer">
      <p>Made by Hardik Kumar</p>
    </footer>
  );
}
